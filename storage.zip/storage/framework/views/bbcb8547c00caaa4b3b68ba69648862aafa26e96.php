<?php $__env->startSection('title'); ?><?php echo e($thistypeinfo->title); ?>-一点点奶茶加盟<?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($thistypeinfo->keywords); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(trim($thistypeinfo->description)); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('headlibs'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <!--幻灯end-->
    <p class="bg-primary"> &nbsp;&nbsp;<a href='/'>主页</a> > <a href='/<?php echo e($thistypeinfo->real_path); ?>/'><?php echo e($thistypeinfo->typename); ?></a> > </p>
    <div class="container-fluid list_clear">
        <div clas="row">

            <div class="ul_list">
                <ul class="list-group">
                    <?php $__currentLoopData = $pagelists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pagelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item relist-group-item">
                            <a href="/<?php echo e($pagelist->arctype->real_path); ?>/<?php echo e($pagelist->id); ?>.shtml"><img src="<?php echo e($pagelist->litpic); ?>" class="col-xs-4 col-md-4 img-responsive img-rounded" /></a>
                            <dl class="col-xs-8 col-md-8" style="padding-top:8px; margin-bottom: 0px; ">
                                <dt><a class="" style="color:#3e7a92;" href="/<?php echo e($pagelist->arctype->real_path); ?>/<?php echo e($pagelist->id); ?>.shtml"><?php echo e($pagelist->title); ?></a></dt>
                                <dd><?php echo e(str_limit($pagelist->description,96,'...')); ?></dd>
                            </dl>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <nav>
                <?php echo str_replace('page=','page/',str_replace('?','/',preg_replace('/<a href=[\'\"]?([^\'\" ]+).*?>/','<a href="${1}/">',$pagelists->links()))); ?>


            </nav>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mobile.mobile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>