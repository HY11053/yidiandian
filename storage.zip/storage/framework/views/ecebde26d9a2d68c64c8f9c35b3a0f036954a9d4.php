<?php $__env->startSection('title'); ?><?php echo e($thisarticleinfos->title); ?>-<?php echo e(config('app.indexname')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($thisarticleinfos->keywords); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($thisarticleinfos->description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('headlibs'); ?>
    <meta name="Copyright" content="<?php echo e(config('app.name')); ?>-<?php echo e(config('app.url')); ?>"/>
    <meta name="author" content="<?php echo e(config('app.name')); ?>" />
    <meta http-equiv="mobile-agent" content="format=wml; url=<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" />
    <meta http-equiv="mobile-agent" content="format=xhtml; url=<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" />
    <meta http-equiv="mobile-agent" content="format=html5; url=<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" />
    <link rel="alternate" media="only screen and(max-width: 640px)" href="<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" >
    <link rel="canonical" href="<?php echo e(config('app.url')); ?><?php echo e(str_replace('','',Request::getrequesturi())); ?>"/>
    <meta property="og:type" content="article"/>
    <meta property="article:published_time" content="<?php echo e($thisarticleinfos->created_at); ?>+08:00" />
    <meta property="og:image" content="<?php echo e(config('app.url')); ?><?php echo e(str_replace(config('app.url'),'',$thisarticleinfos->litpic)); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <div class="ydd_con list_nav">
        <div class="ydd_1000">
            <div class="ln_l">产品中心</div>
            <div class="ln_r">当前位置：<a href="/">主页</a> &gt; <a href="/<?php echo e($thisarticleinfos->arctype->real_path); ?>/"><?php echo e($thisarticleinfos->arctype->typename); ?></a> &gt; </div>
        </div>
    </div>
    <div class="ydd_con">
        <div class="ydd_1000 list_a">
            <div class="list_l" id="inner">
                <div class="l_img"><img src="/frontend/images/list_06.jpg" width="250" height="170" alt="一点点奶茶新鲜" data-bd-imgshare-binded="1"></div>
                <div class="l_img"><a href="#"><img src="/frontend/images/list_09.jpg" width="250" height="68" alt="一点点奶茶申请" data-bd-imgshare-binded="1"></a></div>
                <div class="l_ts">
                    <p>信息推荐</p>
                    <ul>
                        <?php $__currentLoopData = $latesenews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latesenew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/<?php echo e($latesenew->arctype->real_path); ?>/<?php echo e($latesenew->id); ?>.shtml"><?php echo e($latesenew->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="list_r">
                <div class="newsnr">
                    <h1><p align="center"><strong><font size="4"><?php echo e($thisarticleinfos->title); ?></font></strong></p></h1>
                    <center>时间：<?php echo e($thisarticleinfos->created_at); ?> </center>
                    <div>
                        　　<?php echo $thisarticleinfos->body; ?>

                    </div>
                    <div class="bdsharebuttonbox bdshare-button-style0-24" data-bd-bind="1544972799724"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a></div>
                    <script>
                        window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
                    </script>
                </div>
                <div class="sxp">
                    <ul>
                        <li>上一篇：<?php if(isset($prev_article)): ?> <span>上一篇：<a href="<?php echo e(config('app.url')); ?>/<?php echo e($prev_article->arctype->real_path); ?>/<?php echo e($prev_article->id); ?>.shtml" title="<?php echo e($prev_article->title); ?>"><?php echo e(str_limit($prev_article->title,40,'')); ?></a></span> <?php else: ?> 没有了 <?php endif; ?>  </li>
                        <li>下一篇：<?php if(isset($next_article)): ?>  <span class="right">下一篇：<a href="<?php echo e(config('app.url')); ?>/<?php echo e($prev_article->arctype->real_path); ?>/<?php echo e($next_article->id); ?>.shtml" title="<?php echo e($next_article->title); ?>"><?php echo e(str_limit($next_article->title,40,'')); ?></a></span> <?php else: ?> 没有了 <?php endif; ?> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>