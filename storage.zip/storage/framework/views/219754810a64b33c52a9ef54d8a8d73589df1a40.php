<?php $__env->startSection('title'); ?>网站文档列表<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
<style>.red{color: red;}</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">文档列表管理 文档总计<?php echo e($articles->total()); ?></h3>
                       <div class="box-tools">
                           <div class="pull-right" style="display:inline-block; width: 210px">
                               <a href="<?php echo e(action('Admin\ArticleController@Create')); ?>" style="color: #ffffff ; display: inline-block; padding-left: 3px;"><button  class="btn btn-sm btn-default bg-blue"><i class="fa  fa-pencil-square" style="padding-right: 3px;"></i>添加文档</button></a>
                               <a href="<?php echo e(action('Admin\ArticleController@BrandCreate')); ?>" style="color: #ffffff; display: inline-block; padding-left: 3px;"><button  class="btn btn-sm btn-default bg-purple"><i class="fa  fa-pencil-square-o" style="padding-right: 3px;"></i>添加品牌文档</button></a>
                           </div>
                           <form action="/admin/brand_search" method="post" class="form-group pull-right col-md-2 col-xs-6">
                               <div class="input-group input-group-sm ">
                                   <input type="text" name="title" class="form-control pull-right" placeholder="品牌搜索">
                                   <?php echo e(csrf_field()); ?>

                                   <div class="input-group-btn">
                                       <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                   </div>
                               </div>
                           </form>
                       </div>
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <tr>
                                <th>ID</th>
                                <th>文章标题</th>
                                <th>栏目</th>
                                <th>发布时间</th>
                                <th>发布人</th>
                                <th>点击</th>
                                <th>状态</th>
                                <th>操作</th>
                            </tr>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($article->id); ?></td>
                                <td><?php if($article->ismake): ?> <?php echo e($article->title); ?> <?php else: ?> <s class="red"><?php echo e($article->title); ?></s> <?php endif; ?> </td>
                                <td><?php echo e($article->arctype->typename); ?></td>
                                <td><?php echo e($article->created_at); ?></td>
                                <td><?php echo e($article->write); ?></td>
                                <td><?php echo e($article->click); ?></td>
                                <td><?php if($article->ismake): ?> 已审核 <?php else: ?> <s class="red">未审核</s> <?php endif; ?></td>
                                <td class="astyle"><span class="label label-success"><a href="/<?php echo e($article->arctype->real_path); ?>/<?php echo e($article->id); ?>.shtml" target="_blank">预览</a></span><span class="label label-warning"><a href="/admin/article/edit/<?php echo e($article->id); ?>">编辑</a></span><span class="label label-danger"><a data-toggle="modal" data-target=".modal-sm<?php echo e($article->id); ?>" >删除</a></span>
                                    <div class="modal fade modal-sm<?php echo e($article->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel<?php echo e($article->id); ?>">
                                        <div class="modal-dialog modal-sm modal-s-m<?php echo e($article->id); ?>" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    <h5 class="modal-title" id="mySmallModalLabel<?php echo e($article->id); ?>">是否要删除当前文章</h5>
                                                </div>
                                                <div class="modal-body">
                                                    <?php echo e($article->title); ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">返回</button>
                                                    <button type="button" class="btn btn-primary" id="btn-<?php echo e($article->id); ?>" onclick="AjDelete(<?php echo e($article->id); ?>,'modal-s-m<?php echo e($article->id); ?>')">删除</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                        <?php echo $articles->links(); ?>


                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>

    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('libs'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })
        });
        function startRequest() {
            window.location.reload()
        }
        function AjDelete (id,node) {
            var id = id;
            var node=node;
            $.ajax({
                //提交数据的类型 POST GET
                type:"POST",
                //提交的网址
                url:"/admin/article/delete/"+id,
                //提交的数据
                data:{"id":id,'node':node},
                //返回数据的格式
                datatype: "html",    //"xml", "html", "script", "json", "jsonp", "text".
                success:function (response, stutas, xhr) {
                    $(".modal-s-m"+id+" .modal-body").html(response);
                    $("#btn-"+id).attr("disabled","disabled");
                    setInterval("startRequest()", 600);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>