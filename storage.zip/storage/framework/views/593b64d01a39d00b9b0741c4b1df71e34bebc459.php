<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.0.1
    </div>
    <strong>Copyright &copy; 2017-2018 <a href="https://github.com/HY11053/laravelcms">YSG 1 Department</a>.</strong> All rights
    reserved.
</footer>
