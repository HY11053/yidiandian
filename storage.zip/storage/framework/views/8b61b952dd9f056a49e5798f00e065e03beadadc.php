<?php $__env->startSection('title'); ?>前台会员列表
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
<style>td.newcolor span a{color: #ffffff; font-weight: 400; display: inline-block; padding: 2px;} td.newcolor span{margin-left: 5px;}</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">后台用户列表</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th style="width: 10px">#ID</th>
                            <th>用户名</th>
                            <th>账号</th>
                            <th>所属公司</th>
                            <th>旗下品牌</th>
                            <th>最近充值</th>
                            <th>充值操作</th>
                            <th>剩余积分</th>
                            <th>总计充值</th>
                            <th>创建时间</th>
                            <th>更改时间</th>
                            <th>操作</th>
                        </tr>
                        <?php $__currentLoopData = $userlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($userlist->id); ?>.</td>
                            <td><?php echo e($userlist->name); ?></td>
                            <td><?php echo e($userlist->email); ?></td>
                            <td><?php echo e($userlist->group); ?></td>
                            <td><?php echo e($userlist->brandname); ?></td>
                            <td><?php echo e($userlist->score); ?></td>
                            <td><?php echo e($userlist->email); ?></td>
                            <td><?php echo e($userlist->remain_score); ?></td>
                            <td><?php echo e($userlist->total_score); ?></td>
                            <td><?php echo e($userlist->created_at); ?></td>
                            <td><?php echo e($userlist->updated_at); ?></td>
                            <td class="newcolor"><span class="badge bg-green"><a href="/admin/user/edit/<?php echo e($userlist->id); ?>">编辑</a></span></td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    
                </div>
            </div>
            <!-- /.box -->
        </div>

    </div>
    <!-- /.row -->
    <!-- /.content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>