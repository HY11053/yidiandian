<?php $__env->startSection('title'); ?>系统运行信息<?php $__env->stopSection(); ?>
    <?php $__env->startSection('head'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="right_col" role="main">
            简介：LARSTYCMSV2.0 是基于laravel5.5框架开发的CMS系统
            <hr/>
            当前版本V2.0
            <hr/>
            运行环境信息：<?php echo e($_SERVER['SERVER_SOFTWARE']); ?>

            <hr/>
            数据库类型：<?php echo e(env('DB_CONNECTION')); ?>

            <hr/>
            当前登录用户名：<?php echo e(auth('admin')->user()->name); ?>

            <hr/>
            文章总数：<?php echo e(\App\AdminModel\Archive::max('id')); ?>

            <hr/>
            问答总数：<?php echo e(\App\AdminModel\Ask::max('id')); ?>

            <hr/>
            收录量：
            <hr/>
            当日收录：
            <hr/>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>