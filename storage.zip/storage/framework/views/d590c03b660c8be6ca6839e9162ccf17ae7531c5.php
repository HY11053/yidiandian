<?php $__env->startSection('title'); ?>网站文档列表<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <style>.red{color: red;}</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">文档列表管理 文档总计<?php echo e($articles->total()); ?></h3>
                    <div class="box-tools">
                        <div class="pull-right" style="display:inline-block; width: 210px">
                            <a href="<?php echo e(action('Admin\ArticleController@Create')); ?>" style="color: #ffffff ; display: inline-block; padding-left: 3px;"><button  class="btn btn-sm btn-default bg-blue"><i class="fa  fa-pencil-square" style="padding-right: 3px;"></i>添加文档</button></a>
                            <a href="<?php echo e(action('Admin\ArticleController@BrandCreate')); ?>" style="color: #ffffff; display: inline-block; padding-left: 3px;"><button  class="btn btn-sm btn-default bg-purple"><i class="fa  fa-pencil-square-o" style="padding-right: 3px;"></i>添加品牌文档</button></a>
                        </div>
                        <form action="/admin/brand_search" method="post" class="form-group pull-right col-md-2 col-xs-6">
                            <div class="input-group input-group-sm ">
                                <input type="text" name="title" class="form-control pull-right" placeholder="品牌搜索">
                                <?php echo e(csrf_field()); ?>

                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>ID</th>
                            <th>文章标题</th>
                            <th>栏目</th>
                            <th>发布时间</th>
                            <th>点击</th>
                            <th>状态</th>
                            <th>领取人</th>
                            <th>操作</th>
                        </tr>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($article->id); ?></td>
                                <td><?php if($article->ismake): ?> <?php echo e($article->title); ?> <?php else: ?> <s class="red"><?php echo e($article->title); ?></s> <?php endif; ?> </td>
                                <td><?php echo e($article->arctype->typename); ?></td>
                                <td><?php echo e($article->created_at); ?></td>
                                <td><?php echo e($article->click); ?></td>
                                <td><?php if($article->editor_id): ?> 已领取 <?php else: ?> <span id="update_<?php echo e($article->id); ?>" class="red" style="text-decoration:line-through">未领取</span> <?php endif; ?></td>
                                <td><span id="update_n<?php echo e($article->id); ?>"><?php if($article->editor): ?><?php echo e($article->editor); ?> <?php else: ?> 暂无领取 <?php endif; ?></span></td>
                                <?php if(!$article->editor_id): ?>
                                <td class="astyle"><span class="label label-success"><a href="/news/<?php echo e($article->id); ?>.shtml" target="_blank">预览</a></span><span class="label label-warning"><a href="/admin/article/brandedit/<?php echo e($article->id); ?>">编辑</a></span><span class="label label-danger" style="cursor: pointer" id="btn_<?php echo e($article->id); ?>" onclick="updateReceive(<?php echo e($article->id); ?>)">未领取</span>
                                <?php else: ?>
                                <td class="astyle"><span class="label label-success"><a href="/news/<?php echo e($article->id); ?>.shtml" target="_blank">预览</a></span><span class="label label-warning"><a href="/admin/article/brandedit/<?php echo e($article->id); ?>">编辑</a></span><span class="label label-success">已领取</span>
                                <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo $articles->links(); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>

    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('libs'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })
        });
        function updateReceive (id,node) {
            $.ajax({
                type:"POST",
                url:"/admin/article/updatereceive/"+id,
                data:{"id":id},
                datatype: "html",
                success:function (response, stutas, xhr) {
                    alert(response+'！！！请及时认真完善品牌信息 谢谢');
                    $("#btn_"+id).attr("disabled","disabled");
                    $("#btn_"+id).text("已领取").removeClass('label-danger').addClass('label-success').removeAttr("onclick");
                    $("#update_"+id).text("已领取").removeAttr("style").removeClass('red').addClass('green');
                    $("#update_n"+id).text(response[0]);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>