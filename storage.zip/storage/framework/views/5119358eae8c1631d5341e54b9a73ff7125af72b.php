<?php $__env->startSection('title'); ?><?php echo e($thistypeinfo->title); ?>-<?php echo e(config('app.indexname')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo e($thistypeinfo->keywords); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(trim($thistypeinfo->description)); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('headlibs'); ?>
    <meta name="Copyright" content="<?php echo e(config('app.indexname')); ?>-<?php echo e(config('app.url')); ?>"/>
    <meta name="author" content="<?php echo e(config('app.indexname')); ?>" />
    <meta http-equiv="mobile-agent" content="format=wml; url=<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" />
    <meta http-equiv="mobile-agent" content="format=xhtml; url=<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" />
    <meta http-equiv="mobile-agent" content="format=html5; url=<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" />
    <link rel="alternate" media="only screen and(max-width: 640px)" href="<?php echo e(str_replace('http://www.','http://m.',config('app.url'))); ?><?php echo e(Request::getrequesturi()); ?>" >
    <link rel="canonical" href="<?php echo e(config('app.url')); ?><?php echo e(Request::getrequesturi()); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <div class="ydd_con list_nav">
        <div class="ydd_1000">
            <div class="ln_l"><h1>一点点奶茶产品中心</h1></div>
            <div class="ln_r">当前位置：<a href="/">主页</a> &gt; <a href="/<?php echo e($thistypeinfo->real_path); ?>/"><?php echo e($thistypeinfo->typename); ?></a> &gt; </div>
        </div>
    </div>
    <div class="ydd_con">
        <div class="ydd_1000 list_a">
            <div class="list_l" id="inner">
                <div class="l_img"><img src="/frontend/images/list_06.jpg" width="250" height="170" alt="一点点奶茶"></div>
                <div class="l_img"><a href="#"><img src="/frontend/images/list_09.jpg" width="250" height="68" alt="一点点奶茶申请"></a></div>
                <div class="l_ts">
                    <p>信息推荐</p>
                    <ul>
                        <?php $__currentLoopData = $cnewslists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnewslist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><a href="/<?php echo e($cnewslist->arctype->real_path); ?>/<?php echo e($cnewslist->id); ?>.shtml"><?php echo e($cnewslist->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="list_r">
                <ul class="listnb">
                    <?php $__currentLoopData = $pagelists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pagelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <img src="<?php echo e($pagelist->litpic); ?>" width="240" height="180" alt="<?php echo e($pagelist->title); ?>">
                        <div class="newbox">
                            <a href="/<?php echo e($pagelist->arctype->real_path); ?>/<?php echo e($pagelist->id); ?>.shtml"><?php echo e($pagelist->title); ?></a>
                            <p><?php echo e($pagelist->description); ?></p>
                        </div>
                        <div class="datebox">
                            <span><?php echo e($pagelist->created_at); ?></span>
                            <a href="/<?php echo e($pagelist->arctype->real_path); ?>/<?php echo e($pagelist->id); ?>.shtml">查看详情</a>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="main">
                    <div class="btn_pages">
                        <div class="btn-group">
                            <?php echo str_replace('page=','page/',str_replace('?','/',preg_replace('/<a href=[\'\"]?([^\'\" ]+).*?>/','<a href="${1}/">',$pagelists->links()))); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>